package tests;

public @interface Test {

}
