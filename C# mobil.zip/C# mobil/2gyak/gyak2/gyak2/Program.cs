﻿using System;

namespace gyak2
{
    

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Ancestor anc = new Ancestor();
            Descendant des = new Descendant();
            Descendant2 des2 = new Descendant2();

            Ancestor ancParam = new Descendant("asd");
            Descendant desParam = new Descendant2("asd");
            Descendant2 des2Param = new Descendant2("asd");


        }
    }

    class Ancestor
    {
        public Ancestor()
        {
            Console.WriteLine("ancestor");
        }

        public Ancestor(string str)
        {
            Console.WriteLine("ancestor" + str);
        }

        public int five()
        {
            return 5;
        }

        public virtual int ten()
        {
            return 10;
        }
    }

    class Descendant : Ancestor
    {
        public Descendant()
        {
            Console.WriteLine("descendant");
        }

        public Descendant(string str)
        {
            Console.WriteLine("descendant" + str);
        }
    }

    class Descendant2 : Descendant
    {
        public Descendant2()
        {
            Console.WriteLine("descendant 2");
        }

        public Descendant2(string str) : base(str)
        {
            Console.WriteLine("descendant 2" + str);
        }
    }
}
